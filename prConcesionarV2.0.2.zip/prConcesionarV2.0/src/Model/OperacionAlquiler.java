package Model;

public class OperacionAlquiler implements Operaciones{
	//constructor vacio
	public OperacionAlquiler() {
		
		
	}


	@Override
	public void Operacion(GestorVehiculos[] Gestvehiculos) throws ConcesionarioException {
		// TODO Auto-generated method stub
		Vehiculo v = new Vehiculo();
		Usuario u = new Usuario();
		GestorVehiculos gv = new GestorVehiculos();
		int cont = 0;
		
		if(gv.)
		
	}
	
	
	
	
	
	
	
	
}
