package Model;

public class OperacionVenta implements Operaciones{
	//constructor vacio
	public OperacionVenta() {
		
	}

	

	@Override
	public void Operacion(GestorVehiculos[] Gestvehiculos) throws ConcesionarioException {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
	
	
}
