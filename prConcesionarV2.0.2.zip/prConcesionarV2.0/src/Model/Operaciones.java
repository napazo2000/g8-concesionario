package Model;

public interface Operaciones {

	public void Operacion(GestorVehiculos[] Gestvehiculos) throws ConcesionarioException;
	
}
