package Visual;

public class VisualNuevoAlquiler {

}
