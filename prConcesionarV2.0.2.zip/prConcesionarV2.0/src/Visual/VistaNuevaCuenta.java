package Visual;

public class VistaNuevaCuenta {

}
