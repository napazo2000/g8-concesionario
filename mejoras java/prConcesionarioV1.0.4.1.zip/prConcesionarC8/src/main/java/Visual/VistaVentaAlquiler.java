package Visual;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Model.GestorVehiculos;
import Model.Vehiculo;
import Tabla.TablaGestorUsuarios;
import Tabla.TablaGestorVehiculos;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

public class VistaVentaAlquiler extends JFrame {

	private javax.swing.JLabel title;
	private javax.swing.JLabel texto_Vehiculo;
	private javax.swing.JTextField txtCodigoV;
	private javax.swing.JLabel texto_Cliente;
	private javax.swing.JTextField txtCodigoC;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTable tablaVehiculos;
	private javax.swing.JPanel botonera;
	private javax.swing.JButton BtnBack;
	private javax.swing.JButton BtnSig;
	private javax.swing.JButton BtnFiltroV;
	private javax.swing.JButton BtnFiltroC;
	
	
	GestorVehiculos gestorV;
    Vehiculo v = new Vehiculo();
    TablaGestorVehiculos tablaV = new TablaGestorVehiculos();
    TablaGestorUsuarios tablaC = new TablaGestorUsuarios();
    
    int codigoV = 0;
    int codigoC = 0;
	
    public VistaVentaAlquiler() {
        initComponents();
        setExtendedState(MAXIMIZED_BOTH);
        
       tablaV.verVehiculos(tablaVehiculos, "default");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

    	Font negrita = new Font("Calibri", Font.BOLD, 30);
    	
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Asistente de venta");
        
        title = new javax.swing.JLabel();        
        title.setText("  Asistente de ");
        title.setFont(negrita);
        
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVehiculos = new javax.swing.JTable();
        tablaVehiculos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Vehiculo", "Marca", "Modelo", "Estado", "Tipo Oferta", "Precio", "Kilometros", "Cilindrada", "Combustible", "Cambio", "A�o", "Iva", "Unidades", "Imagen"
            }
        ));
        tablaVehiculos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaVehiculosMouseClicked(evt);
            }
        });
        
        jScrollPane1.setViewportView(tablaVehiculos);
            
            
            BtnBack = new javax.swing.JButton();
            BtnBack.setText("Atr�s");
            BtnBack.addActionListener(new java.awt.event.ActionListener() {
            	public void actionPerformed(ActionEvent evt) {
					BtnBackActionPerformed(evt);}
            });
            
            BtnSig = new javax.swing.JButton();
            BtnSig.setText("Siguiente");
            BtnSig.addActionListener(new java.awt.event.ActionListener() {
            	public void actionPerformed(ActionEvent evt) {
					//BtnSigActionPerformed(evt);
				}
            });
            
            
            BtnFiltroV = new javax.swing.JButton();
            BtnFiltroV.setText("Filtrar vehiculo");
            BtnFiltroV.addActionListener(new java.awt.event.ActionListener() {
            	public void actionPerformed(ActionEvent evt) {
            		BtnFiltroVActionPerformed(evt);
				}
            });
           
            BtnFiltroC = new javax.swing.JButton();
            BtnFiltroC.setText("Filtrar cliente");
            BtnFiltroC.addActionListener(new java.awt.event.ActionListener() {
            	public void actionPerformed(ActionEvent evt) {
					BtnFiltroCActionPerformed(evt);	
				}
            });
            
            botonera = new javax.swing.JPanel();
            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(botonera);
            jPanel1Layout.setHorizontalGroup(
            	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
            		.addGroup(jPanel1Layout.createSequentialGroup()
            			.addContainerGap()
            			.addComponent(BtnBack)
            			.addPreferredGap(ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
            			.addComponent(BtnFiltroV)
            			.addGap(70)
            			.addComponent(BtnFiltroC)
            			.addGap(237)
            			.addComponent(BtnSig)
            			.addGap(589))
            );
            jPanel1Layout.setVerticalGroup(
            	jPanel1Layout.createParallelGroup(Alignment.LEADING)
            		.addGroup(jPanel1Layout.createSequentialGroup()
            			.addContainerGap()
            			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
            				.addComponent(BtnBack)
            				.addComponent(BtnFiltroV)
            				.addComponent(BtnSig)
            				.addComponent(BtnFiltroC))
            			.addContainerGap(18, Short.MAX_VALUE))
            );
            botonera.setLayout(jPanel1Layout);
        
        texto_Vehiculo = new javax.swing.JLabel();
        texto_Vehiculo.setText("Veh�culo seleccionado:");
        
        txtCodigoV = new javax.swing.JTextField();
        
        texto_Cliente = new javax.swing.JLabel();
        texto_Cliente.setText("Cliente seleccionado:");
        txtCodigoC = new javax.swing.JTextField();
            
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addComponent(botonera, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 1160, GroupLayout.PREFERRED_SIZE)
        			.addGap(73)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(texto_Vehiculo)
        					.addGap(18)
        					.addComponent(txtCodigoV, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(texto_Cliente)
        					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        					.addComponent(txtCodigoC, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE))))
        		.addGroup(layout.createSequentialGroup()
        			.addGap(915)
        			.addComponent(title, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(890, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(140)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(texto_Vehiculo)
        						.addComponent(txtCodigoV, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addGap(30)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(texto_Cliente)
        						.addComponent(txtCodigoC, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(title, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
        					.addGap(19)
        					.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 544, GroupLayout.PREFERRED_SIZE)))
        			.addGap(12)
        			.addComponent(botonera, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        );
        getContentPane().setLayout(layout);

        pack(); 
    }// </editor-fold>//GEN-END:initComponents

    private void tablaVehiculosMouseClicked(MouseEvent evt) {
    	 int clic = tablaVehiculos.rowAtPoint(evt.getPoint());
       
         codigoV = (int)tablaVehiculos.getValueAt(clic, 0);
         txtCodigoV.setText(String.valueOf(codigoV));
    }
    
    private void BtnBackActionPerformed(ActionEvent evt) {
    	VistaPanelEmpleado v = new VistaPanelEmpleado();
    	v.setVisible(true);
    	dispose();
    }
    
    private void BtnFiltroVActionPerformed(ActionEvent evt) {
    	tablaV.verVehiculos(tablaVehiculos,filtroV.getSelectedItem().toString());
    }
    
    private void BtnFiltroCActionPerformed(ActionEvent evt) {
    	tablaC.verUsuarios(tablaClientes,filtroC.getSelectedItem().toString()); 	
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaVentaAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaVentaAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaVentaAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaVentaAlquiler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaVentaAlquiler().setVisible(true);
            }
        });
    }
}

