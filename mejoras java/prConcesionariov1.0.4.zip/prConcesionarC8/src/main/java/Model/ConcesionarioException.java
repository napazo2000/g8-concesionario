package Model;

@SuppressWarnings("serial")
public class ConcesionarioException extends RuntimeException{

	public ConcesionarioException() {
		super();
	}
	
	public ConcesionarioException(String m) {
		super(m);
	}
	
	
}
