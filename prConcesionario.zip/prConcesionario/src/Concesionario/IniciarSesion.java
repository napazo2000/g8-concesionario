package Concesionario;

public class IniciarSesion {

	private String usuario;
	private String contrase�a;
	public IniciarSesion(String usuario, String contrase�a) {
		super();
		this.usuario = usuario;
		this.contrase�a = contrase�a;
	}
	public String getUsuario() {
		return usuario;
	}
	
	public String getContrase�a() {
		return contrase�a;
	}
	
	
	
	
	
}
