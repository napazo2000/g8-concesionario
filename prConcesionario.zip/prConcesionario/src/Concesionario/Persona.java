package Concesionario;

public abstract class Persona {

	private String correo;
	private String contrase�a;
	private String DNI;
	private String nombre;
	private String apellidos;
	private String fecNacimiento;
	private String direccion;
	private int codPostal;
	private String ciudad;
	private String provincia;
	private char ID;
	private String tipoRol;
	
	
	
	public Persona(String correo, String contrase�a, String dNI, String nombre, String apellidos, String fecNacimiento,
			String direccion, int codPostal, String ciudad, String provincia, char iD, String tipoRol) {
		super();
		this.correo = correo;
		this.contrase�a = contrase�a;
		DNI = dNI;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fecNacimiento = fecNacimiento;
		this.direccion = direccion;
		this.codPostal = codPostal;
		this.ciudad = ciudad;
		this.provincia = provincia;
		ID = iD;
		this.tipoRol = tipoRol;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getContrase�a() {
		return contrase�a;
	}
	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}
	public String getDNI() {
		return DNI;
	}
	public void setDNI(String dNI) {
		DNI = dNI;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getFecNacimiento() {
		return fecNacimiento;
	}
	public void setFecNacimiento(String fecNacimiento) {
		this.fecNacimiento = fecNacimiento;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getCodPostal() {
		return codPostal;
	}
	public void setCodPostal(int codPostal) {
		this.codPostal = codPostal;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	public char getID() {
		return ID;
	}
	public void setID(char iD) {
		ID = iD;
	}
	
	
	public String getTipoRol() {
		return tipoRol;
	}
	public void setTipoRol(String tipoRol) {
		this.tipoRol = tipoRol;
	}
	
	@Override
	public String toString() {
		return "Persona [correo= " + correo + ", \ncontrase�a= " + contrase�a + ", \nDNI= " + DNI + ", \nnombre= " + nombre
				+ ", \napellidos= " + apellidos + ", \nfecNacimiento= " + fecNacimiento + ", \ndireccion= " + direccion
				+ ", \ncodPostal= " + codPostal + ", \nciudad= " + ciudad + ", \nprovincia= " + provincia + ", \nID= " + ID
				+ ", \ntipoRol= " + tipoRol;
	}
	
	
	
	
	
	
}
