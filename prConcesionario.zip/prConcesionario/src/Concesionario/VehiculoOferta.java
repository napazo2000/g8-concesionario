package Concesionario;

public class VehiculoOferta extends Vehiculo{

	private double porcDescuento;

	public VehiculoOferta(String marca, String modelo, String estado, String tipoOferta, String cilindrada,
			String tipoCombustible, String tipocambio, int kilometros, double precio, int anyoFabricacion,
			double porcDescuento) {
		super(marca, modelo, estado, tipoOferta, cilindrada, tipoCombustible, tipocambio, kilometros, precio,
				anyoFabricacion);
		this.porcDescuento = porcDescuento;
	}

	public double getPorcDescuento() {
		return porcDescuento;
	}

	public void setPorcDescuento(double porcDescuento) {
		this.porcDescuento = porcDescuento;
	}

	
	public double getPrecioFinal() {
		return super.precioTotal() - (super.precioTotal()*porcDescuento);
	}

	@Override
	public String toString() {
		return "Precio  Base: "+super.getPrecio()
				+"\nPrecio Con Iva: "+super.precioTotal()
				+"\nPrecio con Descuento: "+getPrecioFinal();
	}
	
	
	
	
}
