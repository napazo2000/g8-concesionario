package Concesionario;

public class Mecanico extends Persona{

	public Mecanico(String correo, String contrase�a, String dNI, String nombre, String apellidos, String fecNacimiento,
			String direccion, int codPostal, String ciudad, String provincia, char iD, String tipoRol) {
		super(correo, contrase�a, dNI, nombre, apellidos, fecNacimiento, direccion, codPostal, ciudad, provincia, iD, tipoRol);
		// TODO Auto-generated constructor stub
	}

	
	
	public void modificarvehiculo(Vehiculo v, String rol) {
		/*
		if(mecanico) {
			Lo que haga el mecanico else if(admin || empleado) {  
			 *  lo que hagan estos dos
			 *  } else { 
			 *   error: no tiene permisos} 
			 */
		}
	*/
	}
		
	}
	
	
	
	
	
}
