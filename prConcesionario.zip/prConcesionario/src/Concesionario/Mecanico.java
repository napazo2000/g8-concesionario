package Concesionario;

public class Mecanico extends Persona{

	public Mecanico(String correo, String contrase�a, String dNI, String nombre, String apellidos, String fecNacimiento,
			String direccion, int codPostal, String ciudad, String provincia, char iD, String tipoRol) {
		super(correo, contrase�a, dNI, nombre, apellidos, fecNacimiento, direccion, codPostal, ciudad, provincia, iD, tipoRol);
	}

	
	
	public void modificarVehiculo(Vehiculo v, String estado) {
		//Acciones que hara el mecanico sobre el vehiculo, comprobara que el vehiculo este en la BD,
		// y har� un set para cambiar el estado del vehiculoa disponible o mantenimiento
	
	}
	
	
@Override
	public String toString() {
		return super.toString();
	}
	
}
