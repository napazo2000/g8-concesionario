package Concesionario;

public class GestionPago {

	private String tipoPago;

	public GestionPago(String tipoPago) {
		super();
		this.tipoPago = tipoPago;
	}

	public String getTipoPago() {
		return tipoPago;
	}

	public void setTipoPago(String tipoPago) {
		this.tipoPago = tipoPago;
	}

	@Override
	public String toString() {
		return "tipoPago=" + tipoPago ;
	}
	
	
	
	
	
}
