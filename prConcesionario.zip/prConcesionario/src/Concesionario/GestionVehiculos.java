package Concesionario;

public class GestionVehiculos extends Vehiculo{  //NO TIENE QUE HEREDAR, ES UNA SIMPLE ASOCIACION

	private String Filtro;
	private String tipoGestion;
	
	public GestionVehiculos(String marca, String modelo, String estado, String tipoOferta, String cilindrada,
			String tipoCombustible, String tipocambio, int kilometros, double precio, int anyoFabricacion,
			String filtro, String tipoGestion) {
		super(marca, modelo, estado, tipoOferta, cilindrada, tipoCombustible, tipocambio, kilometros, precio,
				anyoFabricacion);
		Filtro = filtro;
		this.tipoGestion = tipoGestion;
	}

	public String getFiltro() {
		return Filtro;
	}

	public void setFiltro(String filtro) {
		Filtro = filtro;
	}

	public String getTipoGestion() {
		return tipoGestion;
	}

	public void setTipoGestion(String tipoGestion) {
		this.tipoGestion = tipoGestion;
	}
	
	
	public void addVehiculo(Vehiculo v) {
		
	}
	
	public void editVehiculo(Vehiculo v) {
		
	}
	
	public void delVehiculo(Vehiculo v) {
		
	}
	
	public void verVehiculo(Vehiculo v) {
		
	}
	
	public void comprarVehiculo(Vehiculo v, String tipGest) { // (Vehiculo v �sobra? el cliente venia con el vehiculo en el brazo , empleado Empleado, cliente Cliente)
															//Modelar compra y alquiler con una clase diferente.
	}
	
	public void alquilarVehiculo(Vehiculo v, String tipGest) {  //(Vehiculo v , empleado Empleado, cliente Cliente)
		
	}
	
}
