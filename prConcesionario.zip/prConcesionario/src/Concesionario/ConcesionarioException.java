package Concesionario;

public class ConcesionarioException extends RuntimeException{

	public ConcesionarioException() {
		super();
	}
	
	public ConcesionarioException(String m) {
		super(m);
	}
	
	
}
