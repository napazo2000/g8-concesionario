package Concesionario;

public class Empleado extends Persona{

	private String ID_admin;

	
	public Empleado(String correo, String contrase�a, String dNI, String nombre, String apellidos, String fecNacimiento,
			String direccion, int codPostal, String ciudad, String provincia, char iD, String tipoRol,
			String iD_admin) {
		super(correo, contrase�a, dNI, nombre, apellidos, fecNacimiento, direccion, codPostal, ciudad, provincia, iD,
				tipoRol);
		ID_admin = iD_admin;
	}

	public void eliminarEmpleado(Empleado emp,String Id, String rol) {
		
	}
	
	public void modificarCliente(Cliente clt, String tipOp, Vehiculo v, String tipVeh) {
		
	}
	
	public void crearFichaCliente(Persona p) {
		
	}
	
}
