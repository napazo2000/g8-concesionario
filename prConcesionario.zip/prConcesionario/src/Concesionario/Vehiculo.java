package Concesionario;

public class Vehiculo {

	private String marca;
	private String modelo;
	private String estado;
	private String tipoOferta;
	private String Cilindrada;
	private String tipoCombustible;
	private String tipocambio;
	private int kilometros;
	private double precio;
	private int anyoFabricacion;
	private static final double iva = 0.21;
	private String tipoPago; //Seria tipodeOperacion y ya dentro de si es venta o alquiler, el tipo de pago que va realizar
	
	
	


	public Vehiculo(String marca, String modelo, String estado, String tipoOferta, String cilindrada,
			String tipoCombustible, String tipocambio, int kilometros, double precio, int anyoFabricacion) {

		this.marca = marca;
		this.modelo = modelo;
		this.estado = estado;
		this.tipoOferta = tipoOferta;
		Cilindrada = cilindrada;
		this.tipoCombustible = tipoCombustible;
		this.tipocambio = tipocambio;
		this.kilometros = kilometros;
		this.precio = precio;
		this.anyoFabricacion = anyoFabricacion;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public static double getIva() {
		return iva;
	}

	public String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public String getEstado() {
		return estado;
	}


	public void setEstado(String estado) {
		this.estado = estado;
	}


	public String getTipoOferta() {
		return tipoOferta;
	}


	public void setTipoOferta(String tipoOferta) {
		this.tipoOferta = tipoOferta;
	}


	public String getCilindrada() {
		return Cilindrada;
	}


	public void setCilindrada(String cilindrada) {
		Cilindrada = cilindrada;
	}


	public String getTipoCombustible() {
		return tipoCombustible;
	}


	public void setTipoCombustible(String tipoCombustible) {
		this.tipoCombustible = tipoCombustible;
	}


	public String getTipocambio() {
		return tipocambio;
	}


	public void setTipocambio(String tipocambio) {
		this.tipocambio = tipocambio;
	}


	public int getKilometros() {
		return kilometros;
	}


	public void setKilometros(int kilometros) {
		this.kilometros = kilometros;
	}


	public double getPrecio() {
		return precio;
	}


	public void setPrecio(double precio) {
		this.precio = precio;
	}


	public int getAnyoFabricacion() {
		return anyoFabricacion;
	}


	public void setAnyoFabricacion(int anyoFabricacion) { 
		this.anyoFabricacion = anyoFabricacion;
	}


	public double precioTotal() {
		return precio + precio*iva;
	}
	
	
	public String getTipoPago() {
		return tipoPago;
	}


	public void setTipoPago(String tipoPago) {
		this.tipoPago = tipoPago;
	}
	
	
	
	@Override
	public String toString() {
		return "Vehiculo [marca= " + marca + ", \nmodelo= " + modelo + ", \nestado= " + estado + ", \ntipoOferta= " + tipoOferta
				+ ", \nCilindrada= " + Cilindrada + ", \ntipoCombustible= " + tipoCombustible + ", \ntipocambio= " + tipocambio
				+ ", \nkilometros= " + kilometros + ", \nprecio= " + precio + ", \nanyoFabricacion= " + anyoFabricacion + "]";
	}
	
	
	
	
	
	
	
	
}
