package Concesionario;

public class Cliente extends Persona{

	private String tipoOperacion;
	private String tipoVehiculo;
	
	

	public Cliente(String correo, String contrase�a, String dNI, String nombre, String apellidos, String fecNacimiento,
			String direccion, int codPostal, String ciudad, String provincia, char iD, String tipoRol,
			String tipoOperacion, String tipoVehiculo) {
		super(correo, contrase�a, dNI, nombre, apellidos, fecNacimiento, direccion, codPostal, ciudad, provincia, iD,
				tipoRol);
		this.tipoOperacion = tipoOperacion;
		this.tipoVehiculo = tipoVehiculo;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public String getTipoVehiculo() {
		return tipoVehiculo;
	}

	public void setTipoVehiculo(String tipoVehiculo) {
		this.tipoVehiculo = tipoVehiculo;
	}
	
	
	
	
	
	
	
}
