package Visual;

public class VistaMiPerfil extends javax.swing.JFrame {
	private javax.swing.JButton BtnFoto;
    private javax.swing.JButton BtnAdd;
    private javax.swing.JButton BtnEdit;
    private javax.swing.JButton BtnDel;
    private javax.swing.JButton BtnClean;
    private javax.swing.JButton BtnBack;
    private javax.swing.JButton BtnSearch;
    
    private javax.swing.JLabel texto_Password;
    private javax.swing.JLabel texto_Correo;
    private javax.swing.JLabel texto_Codigo;
    private javax.swing.JLabel texto_Dni;
    private javax.swing.JLabel texto_Nombre;
    private javax.swing.JLabel texto_Apellidos;
    private javax.swing.JLabel texto_FecNac;
    private javax.swing.JLabel texto_Movil;
    private javax.swing.JLabel texto_Direccion;
    private javax.swing.JLabel texto_CodPostal;
    private javax.swing.JLabel texto_Ciudad;
    private javax.swing.JLabel texto_Provincia;
    
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    
    private javax.swing.JTextField txtc;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtRuta;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtFecNac;
    private javax.swing.JTextField txtMovil;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtCodPostal;
    private javax.swing.JTextField txtCiudad;
    private javax.swing.JTextField txtProvincia;
}
